from django.contrib import admin

# Register your models here.


from Bloodapp.models import Donar,Patient

class  DonarAdmin(admin.ModelAdmin):
    list_display=['Donar_name','Donar_email','Donar_age','Donar_bloodGroup','Donar_Unit','Donar_dat','Donar_disease']


admin.site.register(Donar,DonarAdmin)
admin.site.register(Patient)

